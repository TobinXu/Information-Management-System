package com.dao.inter;

import java.util.List;

public interface SystemDaoInter extends BaseDaoInter {
	
	
}
