package com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

import com.dao.inter.SystemDaoInter;
import com.lizhou.bean.Clazz;
import com.lizhou.bean.Grade;
import com.lizhou.bean.Student;
import com.lizhou.tools.MysqlTool;

/**
 * 系统数据层
 *
 */
public class SystemDaoImpl extends BaseDaoImpl implements SystemDaoInter {

	
	
	
	
}
